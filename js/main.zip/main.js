// Main site JS: includes loader, theme, nav, data-driven projects, and scroll effects
(function () {
  const isReduced = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  // Helper: load includes (header/footer)
  async function loadIncludes() {
    const includeNodes = document.querySelectorAll("[data-include]");
    await Promise.all(
      Array.from(includeNodes).map(async (node) => {
        let src = node.getAttribute("data-include");
        // Allow shorthand values: 'header' | 'footer'
        if (src === "header") src = "_includes/header.html";
        if (src === "footer") src = "_includes/footer.html";
        const res = await fetch(src);
        const html = await res.text();
        node.outerHTML = html;
      })
    );
  }

  // Theme persistence
  function initTheme() {
    const saved = localStorage.getItem("theme");
    if (saved === "light") document.body.classList.add("theme-light");
    const toggle = document.getElementById("themeToggle");
    if (toggle) {
      toggle.addEventListener("click", () => {
        document.body.classList.toggle("theme-dark");
        document.body.classList.toggle("theme-light");
        localStorage.setItem(
          "theme",
          document.body.classList.contains("theme-light") ? "light" : "dark"
        );
      });
    }
  }

  // Mobile nav
  function initNav() {
    const btn = document.getElementById("menuToggle");
    const list = document.getElementById("primaryNav");
    if (!btn || !list) return;
    btn.addEventListener("click", () => {
      const open = list.classList.toggle("open");
      btn.setAttribute("aria-expanded", String(open));
      btn
        .querySelector("use")
        ?.setAttribute(
          "href",
          open
            ? "assets/icons/icons.svg#icon-close"
            : "assets/icons/icons.svg#icon-menu"
        );
    });
  }

  // Render Featured projects on home
  async function renderFeatured() {
    const grid = document.getElementById("featuredGrid");
    if (!grid) return;
    try {
      const data = await (await fetch("data/projects.json")).json();
      data.slice(0, 4).forEach((p) => {
        const card = document.createElement("article");
        card.className = "card";
        card.innerHTML = `
          <img src="${p.image}" alt="${
          p.title
        }" style="width:100%;height:160px;object-fit:cover;border-radius:8px" loading="lazy" decoding="async">
          <h3 style="margin:.6rem 0 .2rem">${p.title}</h3>
          <p style="color:var(--muted);margin:0 0 .6rem">${p.excerpt}</p>
          <div style="display:flex;gap:.5rem;flex-wrap:wrap">${(p.stack || [])
            .map((t) => `<span class="chip">${t}</span>`)
            .join("")}</div>
          <div style="margin-top:.8rem"><a class="btn btn-ghost" href="${
            p.url
          }">Case study</a></div>`;
        grid.appendChild(card);
      });
    } catch (e) {
      console.warn("Could not load projects", e);
    }
  }

  // Render full projects list on /projects/
  async function renderProjectsList() {
    const list = document.getElementById("project-list");
    if (!list) return;
    try {
      const data = await (await fetch("../data/projects.json")).json();
      data.forEach((p) => {
        const card = document.createElement("article");
        card.className = "card";
        card.innerHTML = `
          <img src="${p.image}" alt="${
          p.title
        }" style="width:100%;height:160px;object-fit:cover;border-radius:8px" loading="lazy" decoding="async">
          <h3 style="margin:.6rem 0 .2rem">${p.title}</h3>
          <p style="color:var(--muted);margin:0 0 .6rem">${p.excerpt}</p>
          <div style="display:flex;gap:.5rem;flex-wrap:wrap">${(p.stack || [])
            .map((t) => `<span class='chip'>${t}</span>`)
            .join("")}</div>
          <div style="margin-top:.8rem"><a class="btn btn-ghost" href="${
            p.url
          }">Read more</a></div>`;
        list.appendChild(card);
      });
    } catch (e) {
      console.warn("Could not load project list", e);
    }
  }

  // Scroll reveal
  function initReveal() {
    if (isReduced) return;
    const rObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.style.opacity = 1;
            e.target.style.transform = "translateY(0)";
            rObserver.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    document.querySelectorAll(".card, .chip, .hero-left").forEach((el) => {
      el.style.opacity = 0;
      el.style.transform = "translateY(12px)";
      rObserver.observe(el);
    });
  }

  // Initialize
  document.addEventListener("DOMContentLoaded", async () => {
    // year in footer (if present)
    const yearEl = document.getElementById("year");
    if (yearEl) yearEl.textContent = new Date().getFullYear();

    await loadIncludes();
    initTheme();
    initNav();
    renderFeatured();
    renderProjectsList();
    initReveal();
  });
})();
